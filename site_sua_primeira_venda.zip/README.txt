COMO USAR
1. Abra o arquivo index.html no navegador.
2. Para publicar, envie o index.html para uma hospedagem de sites.
3. Troque o link do botão COMPRAR AGORA pelo seu checkout da Kiwify.
4. Você também pode trocar textos, preço e título diretamente no HTML.

Observação: o layout foi inspirado visualmente no vídeo enviado, mas é um site novo e editável.
